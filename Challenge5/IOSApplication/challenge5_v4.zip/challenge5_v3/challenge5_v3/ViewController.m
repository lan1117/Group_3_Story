//
//  ViewController.m
//  challenge5_v3
//
//  Created by julerrie on 16/10/29.
//  Copyright © 2016年 julerrie. All rights reserved.
//

#import "ViewController.h"
#import "Spark-SDK.h"
#define TEST_USER   @"lanyao1117@163.com"
#define TEST_PASS   @"Yaolan126126"


@interface ViewController ()

@end

SparkDevice *myPhoton;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[SparkCloud sharedInstance] loginWithUser:TEST_USER password:TEST_PASS completion:^(NSError *error) {
        if (!error)
            NSLog(@"Logged in to cloud");
        else
            NSLog(@"Wrong credentials or no internet connectivity, please try again");
    }];
    [[SparkCloud sharedInstance] getDevices:^(NSArray *sparkDevices, NSError *error) {
        NSLog(@"%@",sparkDevices.description); // print all devices claimed to user
        
        for (SparkDevice *device in sparkDevices)
        {
            if ([device.name isEqualToString:@"group3_P5"])
            {
                myPhoton = device;
            NSLog(@"Success!!!");
            NSLog(@"%@", myPhoton.id);
            }
        }
    }];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)test:(UIButton *)sender {
    
  /*  [myPhoton getVariable:@"back" completion:^(id result, NSError *error) {
        if (!error) {
            NSNumber *distance = (NSNumber *)result;
            NSLog(@"distance is %f cm",distance.floatValue);
        }
        else {
            NSLog(@"Failed reading temperature from Photon device");
        }
    }];*/
    
   /* SparkEventHandler handler = ^(SparkEvent *event, NSError *error) {
        if (!error)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"Got Event %@ with data: %@",event.event,event.data);
                _speed.text=event.data;
            });
        }
        else
        {
            NSLog(@"Error occured: %@",error.localizedDescription);
        }
        
    };
    
    // This line actually subscribes to the event stream:
    
    id eventListenerID = [[SparkCloud sharedInstance] subscribeToDeviceEventsWithPrefix:@"left" deviceID:@"270028001847353236343033" handler:handler];
    NSLog(@"%@",eventListenerID);*/
    SparkEventHandler handler = ^(SparkEvent *event, NSError *error) {
        if (!error)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"Got Event %@ with data: %@",event.event,event.data);
                _speed.text=event.data;
            });
        }
        else
        {
            NSLog(@"Error occured: %@",error.localizedDescription);
        }
        
    };
    
    // This line actually subscribes to the event stream:
    
    id eventListenerID = [[SparkCloud sharedInstance] subscribeToDeviceEventsWithPrefix:@"Speed1" deviceID:@"230044001547353236343033" handler:handler];
    NSLog(@"%@",eventListenerID);
    
    

}
- (IBAction)on:(UIButton *)sender {
          //  NSLog(@"%@", myPhoton.id);
    
    NSURLSessionDataTask *task = [myPhoton callFunction:@"fun_test" withArguments:@[@"ON"] completion:^(NSNumber *resultCode, NSError *error) {
        if (!error)
        {
            NSLog(@"LED on D7 successfully turned on");
        }
        else
        {
            NSLog(@"wrong~~");
        }
    }];
  //  int64_t bytesToReceive  = task.countOfBytesExpectedToReceive;
    
   // NSDictionary *myDeviceVariables = myPhoton.variables;
   // NSLog(@"MyDevice first Variable is called %@ and is from type %@", myDeviceVariables.allKeys[0], myDeviceVariables.allValues[0]);
    
    //NSArray *myDeviceFunctions = myPhoton.functions;
    //NSLog(@"MyDevice first Function is called %@", myDeviceFunctions[0]);
    // ..do something with bytesToReceive
    
    
}
- (IBAction)off:(UIButton *)sender {
    NSURLSessionDataTask *task1 = [myPhoton callFunction:@"fun_test" withArguments:@[@"OFF"] completion:^(NSNumber *resultCode, NSError *error) {
        if (!error)
        {
            NSLog(@"LED on D7 successfully turned on");
        }
        else{
            NSLog(@"wrong~~");
        }
    }];
}
- (IBAction)slidervaluechange:(id)sender {
    _sliderdata.text = [NSString stringWithFormat:@"%d",(int)self.speedslider.value];
    int value1 =(int)self.speedslider.value;
    if(value1<=10)
    {
        NSURLSessionDataTask *changespeed1 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"5"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];

    }
    else if(value1>10 && value1<=20)
    {
        NSURLSessionDataTask *changespeed2 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"15"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>20 && value1<=30)
    {
        NSURLSessionDataTask *changespeed3 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"25"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>30 && value1<=40)
    {
        NSURLSessionDataTask *changespeed4 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"35"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>40 && value1<=50)
    {
        NSURLSessionDataTask *changespeed5 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"45"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>50 && value1<=60)
    {
        NSURLSessionDataTask *changespeed6 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"55"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>60 && value1<=70)
    {
        NSURLSessionDataTask *changespeed7 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"65"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>70 && value1<=80)
    {
        NSURLSessionDataTask *changespeed8 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"75"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }
    else if(value1>80 && value1<=90)
    {
        NSURLSessionDataTask *changespeed9 = [myPhoton callFunction:@"fun_test1" withArguments:@[@"85"] completion:^(NSNumber *resultCode, NSError *error) {
            if (!error)
            {
                NSLog(@"LED on D7 successfully turned on");
            }
            NSLog(@"wrong~~");
        }];
        
    }


}

@end
