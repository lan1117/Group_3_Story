//
//  ViewController.h
//  challenge5_v3
//
//  Created by julerrie on 16/10/29.
//  Copyright © 2016年 julerrie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *speed;


@end

