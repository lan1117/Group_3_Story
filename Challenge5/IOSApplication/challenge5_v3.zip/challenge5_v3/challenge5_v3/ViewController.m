//
//  ViewController.m
//  challenge5_v3
//
//  Created by julerrie on 16/10/29.
//  Copyright © 2016年 julerrie. All rights reserved.
//

#import "ViewController.h"
#import "Spark-SDK.h"
#define TEST_USER   @"lanyao1117@163.com"
#define TEST_PASS   @"Yaolan126126"


@interface ViewController ()

@end

SparkDevice *myPhoton;
NSURLSessionDataTask *task;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[SparkCloud sharedInstance] loginWithUser:TEST_USER password:TEST_PASS completion:^(NSError *error) {
        if (!error)
            NSLog(@"Logged in to cloud");
        else
            NSLog(@"Wrong credentials or no internet connectivity, please try again");
    }];
    [[SparkCloud sharedInstance] getDevices:^(NSArray *sparkDevices, NSError *error) {
        NSLog(@"%@",sparkDevices.description); // print all devices claimed to user
        
        for (SparkDevice *device in sparkDevices)
        {
            if ([device.name isEqualToString:@"group3_P2"])
            {
                myPhoton = device;
            NSLog(@"Success!!!");
            NSLog(@"%@", myPhoton.id);
            }
        }
    }];

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)test:(UIButton *)sender {
    
  /*  [myPhoton getVariable:@"back" completion:^(id result, NSError *error) {
        if (!error) {
            NSNumber *distance = (NSNumber *)result;
            NSLog(@"distance is %f cm",distance.floatValue);
        }
        else {
            NSLog(@"Failed reading temperature from Photon device");
        }
    }];*/
    
    SparkEventHandler handler = ^(SparkEvent *event, NSError *error) {
        if (!error)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSLog(@"Got Event %@ with data: %@",event.event,event.data);
                _speed.text=event.data;
            });
        }
        else
        {
            NSLog(@"Error occured: %@",error.localizedDescription);
        }
        
    };
    
    // This line actually subscribes to the event stream:
    
    id eventListenerID = [[SparkCloud sharedInstance] subscribeToDeviceEventsWithPrefix:@"left" deviceID:@"270028001847353236343033" handler:handler];
    NSLog(@"%@",eventListenerID);
}
- (IBAction)on:(UIButton *)sender {
          //  NSLog(@"%@", myPhoton.id);
    [[SparkCloud sharedInstance] getDevices:^(NSArray *sparkDevices, NSError *error) {
        NSLog(@"%@",sparkDevices.description); // print all devices claimed to user
        
        for (SparkDevice *device in sparkDevices)
        {
            if ([device.name isEqualToString:@"group3_P2"])
            {
                myPhoton = device;
                NSLog(@"Success!!!");
                NSLog(@"%@", myPhoton.id);
            }
        }
    }];

    NSURLSessionDataTask *task = [myPhoton callFunction:@"fun_test" withArguments:@[@"ON"] completion:^(NSNumber *resultCode, NSError *error) {
        if (!error)
        {
            NSLog(@"LED on D7 successfully turned on");
        }
        NSLog(@"wrong~~");
    }];
  //  int64_t bytesToReceive  = task.countOfBytesExpectedToReceive;
    
    NSDictionary *myDeviceVariables = myPhoton.variables;
    NSLog(@"MyDevice first Variable is called %@ and is from type %@", myDeviceVariables.allKeys[0], myDeviceVariables.allValues[0]);
    
    NSArray *myDeviceFunctions = myPhoton.functions;
    NSLog(@"MyDevice first Function is called %@", myDeviceFunctions[0]);
    // ..do something with bytesToReceive
    
    
}
- (IBAction)off:(UIButton *)sender {
    NSURLSessionDataTask *task = [myPhoton callFunction:@"fun_test" withArguments:@[@"OFF"] completion:^(NSNumber *resultCode, NSError *error) {
        if (!error)
        {
            NSLog(@"LED on D7 successfully turned on");
        }
        NSLog(@"wrong~~");
    }];
}
- (IBAction)speedselector:(UISlider *)sender {
}


@end
