//
//  ViewController.swift
//  challenge6
//
//  Created by julerrie on 16/11/6.
//  Copyright © 2016年 julerrie. All rights reserved.
//

import UIKit

import SocketIO

let socket = SocketIOClient(socketURL: URL(string: "http://group3story.hopto.org:4000")!,config: [.log(true),.forcePolling(true)])

var newstate=0;
var statebefore=0;
var predictionvar=0;
var errorvar=0;
var num=0;
var errorvar1=0;

class ViewController: UIViewController {
    
    @IBOutlet weak var location: UIImageView!
    @IBOutlet weak var test: UITextField!
    @IBOutlet weak var showpoint: UILabel!
    @IBOutlet weak var prediction: UIImageView!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        //var a = CGPoint(x:70,y:110);
        //location.center=CGPoint()
        var xposition=location.frame.origin.x;
        var yposition=location.frame.origin.y;
        socket.connect()
        socket.on("location"){msg, ack in
        //    print("data is:");
         //   print(msg);
          //  print(msg[0]);
            let states = msg[0] as! NSArray;
            let states1=states[0];
            newstate=(states1 as AnyObject).integerValue;
            print(newstate);
            //if(abs(statebefore-newstate)<=5 || statebefore==0 || statebefore>=45 || newstate<=5)
          //  {
            if (newstate >= 1 && newstate <= 20){
                //   a.y=(390/19)*newstate+110;
                yposition=CGFloat(newstate)*20;
                xposition=75;
                yposition=490-yposition;
                self.location.frame.origin.y=yposition;
                self.location.frame.origin.x=xposition;
                //              CGPoint myPoint = (70,110);
            }
            else if (newstate>20 && newstate<=26)
            {
                xposition=CGFloat(newstate-20)*40;
                xposition=xposition+75;
                yposition=110;
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            else if (newstate>26 && newstate<=45)
            {
                yposition=CGFloat(newstate-25)*20;
                yposition=110+yposition;
                xposition=315;
                self.location.frame.origin.y=yposition;
                self.location.frame.origin.x=xposition;
            }
            else if (newstate>45 && newstate<=50)
            {
                xposition=CGFloat(newstate-45)*40;
                xposition=315-xposition;
                yposition=490;
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            else{
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            //self.showpoint.text=String(newstate);
            statebefore=newstate;
            if(predictionvar != 0 && newstate != 0){
                let newerrorvar=abs(predictionvar-newstate);
                print("newerror  is");
                print(newerrorvar);
                num=num+1;
                print(num);
                errorvar=errorvar+newerrorvar;
                errorvar1=errorvar/num;
                print("errorvar is");
                print(errorvar1);
                self.showpoint.text=String(errorvar1);
                
            }
        //    }
        };
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func testbotton(_ sender: UIButton) {
        let predictiondot:Int = Int(test.text!)!;
        predictionvar=predictiondot;
        var xprediction=prediction.frame.origin.x;
        var yprediction=prediction.frame.origin.y;
        if (predictiondot >= 1 && predictiondot <= 20){
            //   a.y=(390/19)*newstate+110;
            yprediction=CGFloat(predictiondot)*20;
            xprediction=75;
            yprediction=510-yprediction;
            self.prediction.frame.origin.y=yprediction;
            self.prediction.frame.origin.x=xprediction;
            //              CGPoint myPoint = (70,110);
        }
        else if (predictiondot>20 && predictiondot<=26)
        {
            xprediction=CGFloat(predictiondot-20)*40;
            xprediction=xprediction+75;
            yprediction=110;
            self.prediction.frame.origin.y=yprediction;
            self.prediction.frame.origin.x=xprediction;
        }
        else if (predictiondot>26 && predictiondot<=45)
        {
            yprediction=CGFloat(predictiondot-25)*20;
            yprediction=110+yprediction;
            xprediction=315;
            self.prediction.frame.origin.y=yprediction;
            self.prediction.frame.origin.x=xprediction;
        }
        else if (predictiondot>45 && predictiondot<=50)
        {
            xprediction=CGFloat(predictiondot-45)*40;
            xprediction=315-xprediction;
           yprediction=510;
            self.prediction.frame.origin.y=yprediction;
            self.prediction.frame.origin.x=xprediction;
        }
        num=0;
        errorvar=0;



    }
    @IBAction func keyboard(_ sender: UIButton) {
        test.resignFirstResponder();
    }
    

}

