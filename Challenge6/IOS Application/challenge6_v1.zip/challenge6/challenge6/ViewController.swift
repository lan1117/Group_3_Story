//
//  ViewController.swift
//  challenge6
//
//  Created by julerrie on 16/11/6.
//  Copyright © 2016年 julerrie. All rights reserved.
//

import UIKit

import SocketIO

let socket = SocketIOClient(socketURL: URL(string: "http://localhost:4000")!,config: [.log(true),.forcePolling(true)])

var newstate=0;
var statebefore=0;

class ViewController: UIViewController {
    
    @IBOutlet weak var location: UIImageView!
    @IBOutlet weak var test: UITextField!
    @IBOutlet weak var showpoint: UILabel!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        //var a = CGPoint(x:70,y:110);
        //location.center=CGPoint()
        var xposition=location.frame.origin.x;
        var yposition=location.frame.origin.y;
        socket.connect()
        socket.on("location"){msg, ack in
            print("data is:");
            print(msg);
            print(msg[0]);
            let states = msg[0] as! NSArray;
            let states1=states[0];
            newstate=(states1 as AnyObject).integerValue;
            print(newstate);
            //if(abs(statebefore-newstate)<=5 || statebefore==0 || statebefore>=45 || newstate<=5)
          //  {
            if (newstate >= 1 && newstate <= 20){
                //   a.y=(390/19)*newstate+110;
                yposition=CGFloat(newstate)*20;
                xposition=75;
                yposition=490-yposition;
                self.location.frame.origin.y=yposition;
                self.location.frame.origin.x=xposition;
                //              CGPoint myPoint = (70,110);
            }
            else if (newstate>20 && newstate<=26)
            {
                xposition=CGFloat(newstate-20)*40;
                xposition=xposition+75;
                yposition=110;
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            else if (newstate>26 && newstate<=45)
            {
                yposition=CGFloat(newstate-25)*20;
                yposition=110+yposition;
                xposition=315;
                self.location.frame.origin.y=yposition;
                self.location.frame.origin.x=xposition;
            }
            else if (newstate>45 && newstate<=50)
            {
                xposition=CGFloat(newstate-45)*40;
                xposition=315-xposition;
                yposition=490;
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            else{
                self.location.frame.origin.x=xposition;
                self.location.frame.origin.y=yposition;
            }
            self.showpoint.text=String(newstate);
            statebefore=newstate;
        //    }
        };
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 /*   @IBAction func testbotton(_ sender: UIButton) {
        let newstate:Int = Int(test.text!)!;
        var xposition=location.frame.origin.x;
        var yposition=location.frame.origin.y;
        if (newstate >= 1 && newstate <= 20){
            //   a.y=(390/19)*newstate+110;
            yposition=CGFloat(newstate)*20;
            xposition=75;
            yposition=510-yposition;
            self.location.frame.origin.y=yposition;
            self.location.frame.origin.x=xposition;
            //              CGPoint myPoint = (70,110);
        }
        else if (newstate>20 && newstate<=26)
        {
            xposition=CGFloat(newstate-20)*40;
            xposition=xposition+75;
            yposition=110;
            self.location.frame.origin.x=xposition;
            self.location.frame.origin.y=yposition;
        }
        else if (newstate>26 && newstate<=45)
        {
            yposition=CGFloat(newstate-25)*20;
            yposition=110+yposition;
            xposition=315;
            self.location.frame.origin.y=yposition;
            self.location.frame.origin.x=xposition;
        }
        else if (newstate>45 && newstate<=50)
        {
            xposition=CGFloat(newstate-45)*40;
            xposition=315-xposition;
            yposition=510;
            self.location.frame.origin.x=xposition;
            self.location.frame.origin.y=yposition;
        }



    }*/
   // @IBAction func keyboard(_ sender: UIButton) {
        
    //}
    

}

