//
//  AppDelegate.h
//  challenge5_v3
//
//  Created by julerrie on 16/10/29.
//  Copyright © 2016年 julerrie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

