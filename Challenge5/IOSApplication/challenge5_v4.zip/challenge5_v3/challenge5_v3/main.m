//
//  main.m
//  challenge5_v3
//
//  Created by julerrie on 16/10/29.
//  Copyright © 2016年 julerrie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
